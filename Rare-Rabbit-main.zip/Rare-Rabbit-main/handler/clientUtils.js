module.exports = (client) => {
  client.color = "#262733";
  client.website = "https://discord.gg/teamkronix";
  client.email = "https://discord.gg/teamkronix";
  client.support = "https://discord.gg/teamkronix";
  client.sponsor = "https://discord.gg/teamkronix";
};
